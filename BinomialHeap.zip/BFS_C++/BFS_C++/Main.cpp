#include<iostream> 
#include <list> 
using namespace std;

int main()
{
	int[][] matrix = new int[3][3];


	system("pause");
	return 0;
}